---
name: ui-ux-design
description: Modern UI/UX design guidance for web and mobile applications. Use when Codex is building or reviewing user interfaces, designing layouts, choosing color palettes, defining typography, implementing responsive design, improving accessibility/WCAG compliance, adding micro-interactions, or working with Tailwind CSS and Shadcn/ui patterns.
---

# UI/UX Design

Use this skill to make interface decisions before and during implementation. Prefer practical, code-ready guidance over broad design theory.

## Core Workflow

1. Start from the user's product context, audience, and primary workflow.
2. Define the layout mobile-first, beginning at 320px width and progressively enhancing for tablet and desktop.
3. Establish the visual system before coding: color roles, typography scale, spacing rhythm, and component states.
4. Choose interaction patterns that make the main workflow fast, clear, and accessible.
5. Validate the result for responsive behavior, contrast, keyboard navigation, focus visibility, and text fit.

## Design Defaults

- Use an 8px spacing rhythm for layout, padding, gaps, and section spacing.
- Use a clear color system: primary, neutral, success, warning, and error roles.
- Keep body text at 16px or larger unless the surrounding product pattern requires denser UI.
- Use CSS Grid for page structure and Flexbox for component internals.
- Prefer `repeat(auto-fit, minmax(280px, 1fr))` for responsive card or tile grids.
- Keep micro-interactions subtle: 0.2s to 0.3s transitions, animating `transform` and `opacity` when possible.
- Ensure normal text contrast is at least 4.5:1 and UI component contrast is at least 3:1.

## Tailwind And Shadcn/ui

Use Tailwind design tokens before arbitrary values. Prefer responsive utilities such as `w-full md:w-1/2 lg:w-1/3`.

For new Next.js projects, Shadcn/ui setup usually follows:

```bash
npx create-next-app@latest project-name --typescript --tailwind --app
cd project-name
npx shadcn@latest init
```

Add only the Shadcn/ui components needed for the current interface, then customize the generated code in `components/ui/`.

## Pre-Build Checklist

- Confirm the primary workflow and first-screen priority.
- Define the color palette and semantic color roles.
- Choose a typography scale with 6 to 8 sizes.
- Plan mobile, tablet, laptop, and desktop breakpoints.
- Check contrast targets before finalizing colors.
- Specify hover, active, focus, loading, empty, and error states for interactive components.
- Sketch the mobile-to-desktop layout progression before implementing complex screens.

## Reference Files

Load these only when the task needs deeper detail:

- `references/DESIGN_SYSTEM.md`: Use for color systems, typography, spacing, responsive layout, and general UI/UX principles.
- `references/COMPONENTS.md`: Use for component-level patterns, Shadcn/ui usage, forms, cards, dialogs, navigation, and interaction examples.
- `references/ACCESSIBILITY.md`: Use for WCAG checks, keyboard navigation, ARIA guidance, focus states, contrast, and inclusive design validation.
