---
name: style-organic-wellness
description: Create organic wellness pages with natural composition, tactile surfaces, grounded color, generous breathing room, soft editorial imagery, and calm human-centered flow.
---

# Organic Wellness Style

Use this skill for static pages that should feel natural, grounded, human, calm, and tactile.

Before building a page, read:

- `references/style-guide.md`
- `examples/theme.css`

Core direction:

- Use plant, clay, mineral, water, linen, and paper-inspired color.
- Create soft but not bland hierarchy using organic shapes, editorial spacing, and grounded imagery.
- Make flows feel restorative and clear: treatment booking, retreat schedule, product discovery, or wellness dashboard.
- Avoid generic spa beige by adding contrast, editorial detail, and real content structure.

Deliver a complete responsive static page.

