# Organic Wellness Style Guide

## Visual Language

- Palette: moss, mineral blue, clay, charcoal, off-white, soft terracotta.
- Use rounded organic masks sparingly, not as generic blob decoration.
- Texture can come from CSS noise, paper-like backgrounds, thin lines, and layered surfaces.
- Typography should be warm and readable.

## Layout

- Use spacious vertical rhythm, calm navigation, and section breaks that feel like a guided path.
- First viewport should show the service, product, or place, not just atmosphere.
- Use editorial details: ritual steps, ingredient notes, session timeline, practitioner quote, booking state.
- Cards may be used for repeated sessions/products, but keep radius modest and content useful.

## Components

- Buttons: clear, warm, not overly playful.
- Feature blocks: pair plain language with sensory detail.
- Forms: calm, high contrast, easy to scan.

## Avoid

- Beige-only pages.
- Decorative blobs with no purpose.
- Low contrast body text.
- Empty inspirational copy.

