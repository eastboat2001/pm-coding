# Luxury Minimal Style Guide

## Visual Language

- Palette: ivory, charcoal, warm gray, deep green, oxblood, stone, or muted metal.
- Use one accent sparingly. Avoid a one-note beige page.
- Typography should feel composed: elegant serif for display, clean sans for details.
- Use thin dividers, small labels, and measured rhythm.

## Layout

- First viewport should show the product or subject clearly.
- Prefer wide editorial spacing, narrow text columns, and calm image crops.
- Let the next section peek into the viewport to imply depth.
- Use asymmetry with balance, not clutter.

## Components

- Buttons: quiet text buttons or fine bordered controls.
- Product panels: unframed or lightly divided, never heavy cards.
- Details: use specification rows, material notes, provenance, appointments, or tasting notes.

## Avoid

- Heavy gradients.
- Loud shadows.
- Oversized marketing cards.
- Generic black and gold templates.

