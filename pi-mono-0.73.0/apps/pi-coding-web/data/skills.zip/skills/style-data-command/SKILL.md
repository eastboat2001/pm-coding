---
name: style-data-command
description: Create dense operational dashboard pages with enterprise-grade information design, compact controls, comparison tables, status systems, and calm high-signal layout.
---

# Data Command Style

Use this skill for static pages that should feel like an operational dashboard, control room, CRM, analytics console, admin panel, or monitoring workspace.

Before building a page, read:

- `references/style-guide.md`
- `examples/theme.css`

Core direction:

- Prioritize scanning, comparison, status, filters, tables, and repeated workflows.
- Use dense but calm information design.
- Avoid marketing hero composition when the requested app is operational.
- Build controls that look usable: tabs, filters, segmented modes, metric rows, table states, empty/error/loading states.

Deliver a complete static interface with realistic sample data and responsive behavior.

