# Brutalist Editorial Style Guide

## Visual Language

- Background: white or near black.
- Text: high contrast, no muted body copy unless needed for metadata.
- Accent: one loud color such as red, acid green, cobalt, or amber.
- Borders: visible 1px to 3px rules. Use borders to divide information.
- Shapes: rectangles, strips, tables, stamps, and column rules.

## Layout

- Use a grid that is obvious: side rails, numbered rows, split columns, and section indexes.
- Let typography carry the page. Use one giant headline and many compact supporting labels.
- Make sections feel like pages from a newspaper, exhibition catalog, or underground magazine.
- Favor asymmetry, but keep alignment intentional.

## Components

- Navigation: text labels in a ruled bar.
- Hero: giant headline, issue metadata, one sharp call to action.
- Cards: only if they look like clippings, tickets, forms, or index records.
- Buttons: bordered rectangles with clear hover inversion.

## Avoid

- Soft cards.
- Glassmorphism.
- Friendly gradients.
- Decorative blobs.
- Rounded pill-heavy UI.

