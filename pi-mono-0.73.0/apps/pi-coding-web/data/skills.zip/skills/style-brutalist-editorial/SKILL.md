---
name: style-brutalist-editorial
description: Create raw brutalist editorial web pages with hard contrast, oversized typography, visible grids, dense information rhythm, and intentionally unpolished magazine-like structure.
---

# Brutalist Editorial Style

Use this skill for static pages that should feel direct, raw, typographic, and editorial rather than polished SaaS.

Before building a page, read:

- `references/style-guide.md`
- `examples/theme.css`

Core direction:

- Use stark black, white, and one aggressive accent.
- Prefer large type, visible borders, strict grids, labels, indexes, timestamps, and dense hierarchy.
- Make layout feel like an independent magazine, poster wall, archive, or manifesto.
- Avoid rounded cards, soft shadows, gradients, pastel palettes, and generic startup sections.

Deliver a complete static page. Keep the page usable and responsive even when the visual language is intentionally harsh.

