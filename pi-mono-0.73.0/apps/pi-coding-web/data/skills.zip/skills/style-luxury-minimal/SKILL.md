---
name: style-luxury-minimal
description: Create refined luxury minimal pages with quiet composition, generous whitespace, premium typography, restrained color, elegant product focus, and calm high-end detail.
---

# Luxury Minimal Style

Use this skill for static pages that should feel premium, calm, editorial, and carefully composed.

Before building a page, read:

- `references/style-guide.md`
- `examples/theme.css`

Core direction:

- Use whitespace, restrained color, fine rules, elegant type, and precise image/product placement.
- Make the product, venue, object, or offer visible immediately in the first viewport.
- Use fewer elements, but make each element feel deliberate.
- Avoid generic luxury cliches: do not rely on gold-on-black alone.

Deliver a complete static page with polished responsive spacing and strong hierarchy.

