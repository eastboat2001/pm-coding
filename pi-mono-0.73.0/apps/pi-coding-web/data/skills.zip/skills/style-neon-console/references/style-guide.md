# Neon Console Style Guide

## Visual Language

- Palette: black, deep navy, cyan, magenta, lime, violet.
- Use neon accents as edges, labels, rings, and active state indicators.
- Use monospaced type for metadata and system labels.
- Add subtle scanline or grid texture using CSS only.

## Layout

- Think command center: top status bar, active module, telemetry side panel, event log, and action dock.
- Use panels, but make them functional, dense, and informative.
- Avoid empty decorative cards.
- Use clipped corners, thin glowing borders, small status lights, and coordinate labels.

## Components

- Buttons: command buttons with active/inactive states.
- Metrics: compact rows with labels, values, deltas, and bars.
- Hero: product or mission status, not generic marketing copy.
- Background: deep and restrained; text must remain sharp.

## Avoid

- Low contrast gray-on-black text.
- Too many glow effects.
- Random sci-fi words without information structure.

