---
name: style-neon-console
description: Create neon console web pages with cyberpunk command surfaces, terminal-inspired panels, luminous accents, scanline details, and high-energy interactive visual rhythm.
---

# Neon Console Style

Use this skill for static pages that should feel like a futuristic control console, cyberpunk product launch, hacker dashboard, or synth interface.

Before building a page, read:

- `references/style-guide.md`
- `examples/theme.css`

Core direction:

- Use dark surfaces, bright neon accents, monospaced labels, command rows, status indicators, and luminous edges.
- Make the page feel operational and alive without relying on heavy animation.
- Build real UI sections, not a decorative background.
- Keep contrast accessible and text readable.

Deliver a complete static page that works directly from `index.html`.

