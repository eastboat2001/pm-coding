# Data Command Style Guide

## Visual Language

- Palette: neutral background, sharp text, one blue or green action color, severity colors for state.
- Use compact typography and consistent spacing.
- Favor lines, rows, columns, tabs, and table density over decorative cards.
- Cards are allowed for repeated data blocks, but avoid nested cards.

## Layout

- Start with the actual workspace, not a landing page.
- Use a sidebar or top bar only if it improves workflow.
- First viewport should include the main controls and useful data.
- Keep filters close to the data they affect.

## Components

- Metrics: label, value, delta, state.
- Tables: sortable-looking headers, status chips, row actions.
- Panels: compact, labeled, and useful.
- Charts: simple CSS or SVG if needed, but never fake complexity without labels.
- States: include loading, empty, error, or success where relevant.

## Avoid

- Oversized hero type.
- Decorative gradients.
- Vague KPI cards without context.
- Low density SaaS marketing pages.

